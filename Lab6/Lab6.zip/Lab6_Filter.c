/*
 * Lab6_FilterAssembly.c
 *
 *  Created on: Oct 31, 2016
 *      Author: Ish's Master Race PC
 */

#include <DSP28x_Project.h>
#include "OneToOneI2CDriver.h"
#include <DSP2833x_Xintf.h>
#include<DSP2833x_XIntrupt.h>
#include "timer.h"
#include "analogToDigitalConverter.h"
#include "digitalToAnalogConverter.h"
#include "DSP2833x_CpuTimers.h"
#include <DSP2833x_SysCtrl.h>
#include "audioCntrl.h"
#include "Sram.h"
#include "digitalToAnalogConverter.h"
#include "hammingWindow.h"
#include "Lab6_FilterAssembly.h"

//Uint32 iterator;

// put the whole structure in sram if want to use the sram.




int main(void) {

	DisableDog();
	InitPll(10,3);
	analogToDigitalConverter_init();
	Sram_init();
	digitalToAnalogConverter_init();
	timer_init(150,22);


	/*
	 * def struct
	 */
	FIRFilter LPFilter = {0,64,38,{0},&LPFArray[0]};

	/*
	 * The function below is going to send the struct FIRFILTER to the .asm so we can perform the calculations in assembly.
	 * in the following order:
	 * pointer to the array of TAPS, INDEX of all the TAPS array,
	 */
	//analogToDigitalConverter_send();
	//FirFilter(&LPFilter.circularBuffer[0],&LPFilter.circularBuffer[iterator],LPFilter.TapsMax, LPFilter.circularBufferMax);

	LPFilter.circularBuffer[LPFilter.iterator] = (analogToDigitalConverter_send() - 0x7FFF);

	if (LPFilter.circularBuffer[LPFilter.iterator] == 256) {
		LPFilter.iterator = 0;
	}

	//FirFilter(&LPFilter);

	digitalToAnalogConverter_send((Uint16)(FirFilter(&LPFilter)+0x7FFF));
}
