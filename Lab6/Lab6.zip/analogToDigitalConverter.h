/*
 * analogToDigitalConverter.h
 *
 *  Created on: Oct 14, 2016
 *      Author: Ish's Master Race PC
 */

#ifndef ANALOGTODIGITALCONVERTER_H_
#define ANALOGTODIGITALCONVERTER_H_

void  analogToDigitalConverter_init();
Uint16  analogToDigitalConverter_send();


#endif /* ANALOGTODIGITALCONVERTER_H_ */
