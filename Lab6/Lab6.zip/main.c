/*
 * Lab.6 part 1:
 * Making an real time DSP FIR filter with the following parameters:
 * LPF, Pass Band (3 dB ripple) 0-900 Hz, Stop Band (-40 dBs) 3K-22K, F_sampling = 44 KHz;
 */

#include <DSP28x_Project.h>
#include "OneToOneI2CDriver.h"
#include <DSP2833x_Xintf.h>
#include<DSP2833x_XIntrupt.h>
#include "timer.h"
#include "analogToDigitalConverter.h"
#include "digitalToAnalogConverter.h"
#include "DSP2833x_CpuTimers.h"
#include <DSP2833x_SysCtrl.h>
#include "audioCntrl.h"
#include "Sram.h"
#include "digitalToAnalogConverter.h"
#include "hammingWindow.h"


/*

FIR filter designed with
http://t-filter.appspot.com

sampling frequency: 44100 Hz

* 0 Hz - 900 Hz
  gain = 1
  desired ripple = 3 dB
  actual ripple = 1.191066035841248 dB

* 3000 Hz - 22000 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = -45.929675482422645 dB

*/

#define FILTER_TAP_NUM 26
Uint16 j = 0;
double filter_taps[FILTER_TAP_NUM] = {0.00868719587227721,0.00978799761231168,0.0146398731573921,0.0204326085630858,0.0270403726046008,0.0342172002966012,0.0416889063602066,0.0490901455897425,0.0560421502947487,0.0621657775713653,0.0671130040199619,0.0705916329807173,0.0723872586340389,0.0723872586340389,0.0705916329807173,0.0671130040199619,0.0621657775713653,0.0560421502947487,0.0490901455897425,0.0416889063602066,0.0342172002966012,0.0270403726046008,0.0204326085630858,0.0146398731573921,0.00978799761231168,0.00868719587227721};

Uint16 outputOfFIR;



void checkIndex(int currentIndex) {
	currentIndex %=FILTER_TAP_NUM;
}

int main(void) {

	DisableDog();
	InitPll(10,3);
	analogToDigitalConverter_init();
	Sram_init();
	digitalToAnalogConverter_init();
	timer_init(150,22);
	enable_timer_interrupt();
	EALLOW;
	useGpio();


	//TODO: finish the inits and run this code

	while(1) {
		EALLOW;
		while(!interruptTimerFlag);

		bufferForFilters[j] = (analogToDigitalConverter_send() - 0x7FFF); // change the internal offset by making the read value a signed number
		EALLOW;
		GpioDataRegs.GPADAT.bit.GPIO3 = 1;
		for (int i = 0; i < FILTER_TAP_NUM; ++i) {
				outputOfFIR += filter_taps[i]*bufferForFilters[j-i];
		}
		outputOfFIR = (Uint16)((int)outputOfFIR + 0x7FFF); // change back to manage the offset

		digitalToAnalogConverter_send(outputOfFIR);
		j = (j + 1) & (0x00FF);
		EALLOW;
		GpioDataRegs.GPADAT.bit.GPIO3 = 0;
		interruptTimerFlag = 0;

	}
	return 0;
}
