/*
 * digitalToAnalogConverter.h
 *
 *  Created on: Oct 14, 2016
 *      Author: Ish's Master Race PC
 */

#ifndef DIGITALTOANALOGCONVERTER_H_
#define DIGITALTOANALOGCONVERTER_H_

void digitalToAnalogConverter_init();
void digitalToAnalogConverter_send(Uint16 digitalValue);


#endif /* DIGITALTOANALOGCONVERTER_H_ */
