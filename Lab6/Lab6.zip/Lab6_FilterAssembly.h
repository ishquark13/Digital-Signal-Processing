/*
 * Lab6_FilterAssembly.h
 *
 *  Created on: Oct 31, 2016
 *      Author: Ish's Master Race PC
 */
#include <DSP28x_Project.h>
#include "OneToOneI2CDriver.h"
#include <DSP2833x_Xintf.h>
#include<DSP2833x_XIntrupt.h>
#include "timer.h"
#include "analogToDigitalConverter.h"
#include "digitalToAnalogConverter.h"
#include "DSP2833x_CpuTimers.h"
#include <DSP2833x_SysCtrl.h>
#include "audioCntrl.h"
#include "Sram.h"
#include "digitalToAnalogConverter.h"
#include "hammingWindow.h"

#ifndef LAB6_FILTERASSEMBLY_H_
#define LAB6_FILTERASSEMBLY_H_
#define TAPSMAX  38
#define CBUFFERMAX 64

float LPFArray[] = {
		-0.006694,
		-0.004396,
		-0.005155,
		-0.005379,
		-0.004821,
		-0.003219,
		-0.000373,
		0.003854,
		0.009493,
		0.016509,
		0.024691,
		0.033761,
		0.043314,
		0.052876,
		0.061928,
		0.069945,
		0.076443,
		0.081023,
		0.083388,
		0.083388,
		0.081023,
		0.076443,
		0.069945,
		0.061928,
		0.052876,
		0.043314,
		0.033761,
		0.024691,
		0.016509,
		0.009493,
		0.003854,
		-0.000373,
		-0.003219,
		-0.004821,
		-0.005379,
		-0.005155,
		-0.004396,
		-0.006694};

float HPFArray[] = {-0.0479639820732092,0.0129794775534695,0.0170671070587000,0.0222383658551426,0.0259827707896720,0.0255631804786344,0.0188881147359816,0.00493460510262979,-0.0163037636130214,-0.0432518414484733,-0.0729989797156793,-0.101970728706653,-0.126219050546337,-0.142354776197976,0.852011390963695,-0.142354776197976,-0.126219050546337,-0.101970728706653,-0.0729989797156793,-0.0432518414484733,-0.0163037636130214,0.00493460510262979,0.0188881147359816,0.0255631804786344,0.0259827707896720,0.0222383658551426,0.0170671070587000,0.0129794775534695,-0.0479639820732092};






typedef struct
{
	Uint32 iterator;
	Uint32 circularBufferMax;
	Uint16 TapsMax;
	float* circularBuffer; //try a small number a-mode 0
	float* coefficientsOfTaps;
	//change the above to match the type of filter
}FIRFilter;


//extern  Uint32* FirFilter(float*coefficients, float* tapsSize, Uint32 NumTaps, Uint32 BufferSize );
extern float FirFilter(FIRFilter* a);
// a --> attribute of struct
extern Uint32 iterator;


#endif /* LAB6_FILTERASSEMBLY_H_ */
