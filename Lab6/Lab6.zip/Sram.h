/*
 * Sram.h
 *
 *  Created on: Oct 14, 2016
 *      Author: Ish's Master Race PC
 */

#ifndef SRAM_H_
#define SRAM_H_

void Sram_init();



#endif /* SRAM_H_ */
